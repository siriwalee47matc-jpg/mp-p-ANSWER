import{a as h}from"./scan-policy.js";const w="https://sentinel-ads-api.onrender.com".replace(/\/$/,""),k=[{productType:"DRUG",keywords:["drug","medicine","capsule","tablet","antibiotic","ยา"]},{productType:"COSMETIC",keywords:["cosmetic","serum","cream","whitening","beauty","skincare","ครีม"]},{productType:"MEDICAL_DEVICE",keywords:["medical device","test kit","monitor","mask","เครื่องมือแพทย์"]},{productType:"CLINIC",keywords:["clinic","hospital","doctor","treatment center","คลินิก","แพทย์"]},{productType:"HERBAL",keywords:["herbal","botanical","traditional herb","สมุนไพร"]},{productType:"FOOD",keywords:["food","supplement","dietary","beverage","coffee","tea","อาหาร"]}];let f=!1,u=!1,s=!1,b=!1,m;function g(){s||b||chrome.storage.local.get(["extensionMode","autoScan","riskLevel"],t=>{if(!(t.autoScan!==!1&&t.riskLevel!=="MANUAL"))return;const n=document.body.innerText||"",r=h(n),o=r.matchedClaims;r.shouldWarn&&!s&&(f||v(o),u||E(o))})}function T(){const t=window.location.hostname.replace("www.","").toLowerCase();chrome.runtime.sendMessage({action:"CHECK_DOMAIN",domain:t},e=>{e&&e.isBlocked?y(e.reason||"โดเมนนี้ถูกขึ้นบัญชีเฝ้าระวังและบล็อกการเข้าถึงจากศูนย์ควบคุมโฆษณาผิดกฎหมาย"):setTimeout(g,250)})}function E(t){if(u)return;u=!0;const e=document.createElement("div");if(e.id="kp-ad-shield-warning-overlay",e.style.cssText=`
    position: fixed;
    inset: 0;
    background: rgba(5, 46, 43, 0.25);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    z-index: 2147483646;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: "IBM Plex Sans Thai", "Segoe UI", Tahoma, sans-serif;
  `,!document.getElementById("kp-ad-shield-animations")){const i=document.createElement("style");i.id="kp-ad-shield-animations",i.innerHTML=`
      @keyframes kpFadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      @keyframes kpScaleUp {
        from { transform: scale(0.9) translateY(20px); opacity: 0; }
        to { transform: scale(1) translateY(0); opacity: 1; }
      }
    `,document.head.appendChild(i)}e.style.animation="kpFadeIn 0.3s ease-out";const n=document.createElement("div");n.style.cssText=`
    position: relative;
    width: 90%;
    max-width: 480px;
    background: linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(244, 251, 248, 0.98) 100%);
    border: 1px solid rgba(15, 118, 110, 0.22);
    border-radius: 24px;
    padding: 32px;
    box-shadow: 0 24px 80px rgba(5, 46, 43, 0.1), inset 0 1px 1px rgba(255, 255, 255, 0.8);
    color: #052e2b;
    text-align: center;
    animation: kpScaleUp 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    box-sizing: border-box;
  `,n.innerHTML=`
    <button id="warning-close-btn" style="position: absolute; top: 20px; right: 24px; background: transparent; border: none; color: #6f8a87; font-size: 24px; cursor: pointer; transition: color 0.2s; font-weight: 300; line-height: 1;">&times;</button>
    <div style="font-size: 48px; margin-bottom: 16px; display: inline-block;"></div>
    <h2 style="color: #d97706; margin-top: 0; margin-bottom: 12px; font-size: 20px; font-weight: 700; font-family: inherit;">
      ตรวจพบข้อความโฆษณาต้องสงสัย
    </h2>
    <p style="color: #4b6a67; font-size: 14px; line-height: 1.5; margin-bottom: 20px; font-family: inherit;">
      Sentinel ADS ตรวจพบคำอวดอ้างสรรพคุณสุขภาพที่เข้าข่ายเกินจริงหรืออาจผิดกฎหมายบนหน้าเว็บนี้
    </p>
    
    <div style="background: rgba(230, 255, 248, 0.65); border: 1px solid rgba(13, 148, 136, 0.18); padding: 16px 20px; border-radius: 16px; font-size: 13.5px; color: #0f766e; text-align: left; margin-bottom: 24px; max-height: 100px; overflow-y: auto; font-family: inherit; line-height: 1.6;">
      <strong style="color: #052e2b;">สัญญาณที่ตรวจพบ:</strong><br/>
      ${t.map(i=>`• ${i}`).join("<br/>")}
    </div>
    
    <div style="display: flex; gap: 12px; justify-content: center;">
      <button id="warning-bypass-btn" style="background: #047857; border: none; color: #ffffff; padding: 12px 32px; border-radius: 999px; cursor: pointer; font-weight: 700; font-size: 14px; transition: all 0.2s; font-family: inherit; box-shadow: 0 4px 14px rgba(4, 120, 87, 0.25);">
        ยอมรับความเสี่ยงและดูต่อ
      </button>
    </div>
  `,e.appendChild(n),document.body.appendChild(e);const r=n.querySelector("#warning-bypass-btn"),o=n.querySelector("#warning-close-btn");r.onclick=()=>{document.body.removeChild(e),u=!1,b=!0,chrome.runtime.sendMessage({action:"OPEN_EXTENSION_POPUP"})},o.onclick=()=>{document.body.removeChild(e),u=!1,b=!0}}function v(t){f=!0;const e=document.createElement("div");e.id="kp-ad-shield-banner",e.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background: linear-gradient(90deg, #ef4444 0%, #b91c1c 100%);
    color: white;
    z-index: 999999;
    padding: 12px 24px;
    font-family: "Segoe UI", Tahoma, sans-serif;
    font-size: 14px;
    font-weight: 600;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-sizing: border-box;
    gap: 16px;
  `;const n=document.createElement("div");n.innerHTML=`ตรวจพบคำโฆษณาที่อาจเข้าข่ายผิดกฎหมาย <span style="background:rgba(255,255,255,0.2); padding:2px 8px; border-radius:999px; font-size:12px; margin-left:8px;">${t.join(", ")}</span>`,e.appendChild(n);const r=document.createElement("div");r.style.cssText=`
    display: flex;
    gap: 10px;
    align-items: center;
  `;const o=document.createElement("button");o.innerText="ส่งเบาะแส",o.style.cssText=`
    background: white;
    color: #b91c1c;
    border: none;
    padding: 6px 14px;
    border-radius: 999px;
    font-weight: 700;
    cursor: pointer;
    font-size: 13px;
    transition: all 0.2s;
  `,o.onclick=async()=>{o.disabled=!0,o.innerText="กำลังส่ง...";try{const a=document.title||"Suspicious ad page",d=window.location.href,l=`${t.join("; ")} | ${document.body.innerText.substring(0,400)}`,c=z(),p=I(`${a}
${d}
${l}
${c}`);if(!(await fetch(`${w}/cases`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:a,url:d,productType:p,evidenceText:l,imageSignalsText:c,productLicenseNumber:C(document.body.innerText),reporterRole:"SYSTEM"})})).ok)throw new Error("Failed to create case");o.innerText="ส่งสำเร็จ",o.style.background="#d1fae5",o.style.color="#065f46"}catch{o.innerText="ส่งไม่สำเร็จ",o.disabled=!1,setTimeout(()=>{o.innerText="ส่งเบาะแส"},2e3)}},r.appendChild(o);const i=document.createElement("button");i.innerText="×",i.style.cssText=`
    background: transparent;
    border: none;
    color: white;
    font-size: 18px;
    cursor: pointer;
    padding: 0 4px;
  `,i.onclick=()=>{document.body.removeChild(e),document.body.style.marginTop="0px"},r.appendChild(i),e.appendChild(r),document.body.appendChild(e),document.body.style.marginTop="45px"}function S(t){var x;(x=document.getElementById("kp-ad-shield-ai-alert"))==null||x.remove();const e=document.createElement("aside");e.id="kp-ad-shield-ai-alert",e.setAttribute("role","alert"),e.style.cssText=`
    position: fixed;
    top: 18px;
    right: 18px;
    width: min(390px, calc(100vw - 36px));
    z-index: 2147483647;
    box-sizing: border-box;
    padding: 18px;
    border: 1px solid ${t.score>=80?"#fecaca":"#fde68a"};
    border-left: 6px solid ${t.score>=80?"#dc2626":"#d97706"};
    border-radius: 16px;
    background: #ffffff;
    color: #17211d;
    box-shadow: 0 20px 60px rgba(15, 23, 42, 0.24);
    font-family: "IBM Plex Sans Thai", "Segoe UI", Tahoma, sans-serif;
  `;const n=document.createElement("div");n.style.cssText="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px;";const r=document.createElement("strong");r.textContent=t.score>=80?"Sentinel ADS พบความเสี่ยงสูง":"Sentinel ADS พบความเสี่ยงที่ควรตรวจสอบ",r.style.cssText=`font-size:15px;color:${t.score>=80?"#b91c1c":"#92400e"};`;const o=document.createElement("span");o.textContent=`${Math.round(t.score)}%`,o.style.cssText=`padding:4px 9px;border-radius:999px;background:${t.score>=80?"#fee2e2":"#fef3c7"};font-weight:800;`,n.append(r,o);const i=document.createElement("p");i.textContent=(t.analysis||"ผลวิเคราะห์จาก AI แนะนำให้เจ้าหน้าที่ตรวจสอบหน้านี้").slice(0,280),i.style.cssText="margin:0 0 12px;font-size:13px;line-height:1.55;color:#475569;";const a=document.createElement("div");a.style.cssText="display:flex;align-items:center;justify-content:space-between;gap:10px;";const d=document.createElement("span");d.textContent=`คำแนะนำ: ${t.recommendedAction||"REVIEW_REQUIRED"}`,d.style.cssText="font-size:11px;font-weight:700;color:#64748b;";const l=document.createElement("div");l.style.cssText="display:flex;gap:6px;";const c=document.createElement("button");c.textContent="ดูผลตรวจ",c.style.cssText="border:0;border-radius:999px;padding:7px 12px;background:#047857;color:white;font-weight:700;cursor:pointer;",c.onclick=()=>chrome.runtime.sendMessage({action:"OPEN_EXTENSION_POPUP"});const p=document.createElement("button");p.textContent="ปิด",p.style.cssText="border:1px solid #cbd5e1;border-radius:999px;padding:7px 10px;background:white;color:#475569;font-weight:700;cursor:pointer;",p.onclick=()=>e.remove(),l.append(c,p),a.append(d,l),e.append(n,i,a),document.body.appendChild(e)}function y(t){s=!0;const e=document.getElementById("kp-ad-shield-banner");e&&(document.body.removeChild(e),document.body.style.marginTop="0px");const n=document.createElement("div");n.id="kp-ad-shield-block-screen",n.style.cssText=`
    position: fixed;
    inset: 0;
    background: #080a10;
    z-index: 2147483647;
    font-family: "Segoe UI", Tahoma, sans-serif;
    color: #f3f4f6;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 40px;
    text-align: center;
    box-sizing: border-box;
  `,n.innerHTML=`
    <div style="max-width: 600px; padding: 40px; border: 1px solid rgba(239, 68, 68, 0.2); border-radius: 24px; background: rgba(17, 24, 39, 0.88); box-shadow: 0 10px 40px rgba(0,0,0,0.5);">
      <div style="font-size: 4rem; margin-bottom: 20px;">ปิดกั้นแล้ว</div>
      <h1 style="color: #ef4444; font-size: 1.85rem; margin-bottom: 12px; font-weight: 700;">เว็บไซต์นี้ถูกบล็อกโดย Sentinel ADS</h1>
      <p style="color: #f3f4f6; font-size: 15px; line-height: 1.6; margin-bottom: 20px;">
        ระบบตรวจพบสัญญาณความเสี่ยงโฆษณาสุขภาพผิดกฎหมายและระงับการเข้าถึงชั่วคราวเพื่อความปลอดภัย
      </p>
      <div style="background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.2); padding: 15px; border-radius: 12px; font-size: 13.5px; color: #fca5a5; text-align: left; margin-bottom: 24px; line-height: 1.5;">
        <strong>เหตุผล:</strong> ${t}
      </div>
      <div style="display: flex; justify-content: center; gap: 15px; flex-wrap: wrap;">
        <button id="kp-bypass-btn" style="background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.1); color: #d1d5db; padding: 10px 20px; border-radius: 999px; cursor: pointer; font-size: 13px;">
          เข้าต่อด้วยความเสี่ยงของผู้ใช้
        </button>
        <button id="kp-back-btn" style="background: #ef4444; border: none; color: white; padding: 10px 24px; border-radius: 999px; cursor: pointer; font-weight: 700; font-size: 13.5px;">
          กลับไปหน้าที่ปลอดภัย
        </button>
      </div>
    </div>
  `,document.body.appendChild(n),document.body.style.overflow="hidden",document.getElementById("kp-back-btn").onclick=()=>{window.history.back(),setTimeout(()=>window.close(),500)},document.getElementById("kp-bypass-btn").onclick=()=>{document.body.removeChild(n),document.body.style.overflow="auto",s=!1}}function C(t){const e=t.match(/\d{2}-\d-\d{5}-\d-\d{4}/);return e?e[0]:""}function z(){const t=Array.from(document.images).slice(0,12).map(n=>[n.alt||"",n.title||"",n.getAttribute("aria-label")||"",n.src.split("/").pop()||""].join(" ")).join(" | "),e=Array.from(document.querySelectorAll('figcaption, [data-testid*="caption"], .caption')).slice(0,12).map(n=>(n.textContent||"").trim()).filter(Boolean).join(" | ");return[t,e].filter(Boolean).join(" | ")}function I(t){const e=t.toLowerCase();let n="FOOD",r=-1;for(const o of k){const i=o.keywords.reduce((a,d)=>a+(e.includes(d.toLowerCase())?1:0),0);i>r&&(n=o.productType,r=i)}return n}chrome.runtime.onMessage.addListener(t=>{t.action==="BLOCK_SCREEN"&&!s?y(t.reason):t.action==="SCAN_RESULT"&&!s&&S(t)});T();const A=new MutationObserver(()=>{s||b||(window.clearTimeout(m),m=window.setTimeout(g,600))});A.observe(document.documentElement,{childList:!0,subtree:!0,characterData:!0});
