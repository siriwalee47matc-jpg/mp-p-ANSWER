const s=e=>e.replace(/\/$/,""),t=s("https://sentinel-ads-api.onrender.com"),n=s("https://sentinel-ads-ssk.vercel.app");export{t as A,n as D};
